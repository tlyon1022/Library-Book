﻿//K9195
/*CIS 199-02
 * Program 4
 * December 3rd, 2019
 * K9195
 * LibraryBook Class declaration with one constructor that uses defaults
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class LibraryBook
{
    //Library Book Constructor
    // Precondition:  Title, Author, Publisher and Call Number = string
    //                Copyright Year >=0         
    // Postcondition: The LibraryBook object has been initialized with the specified
    //                Title, Author, Publisher, Copyright Year and Call Number
    public LibraryBook(string t, string a, string p, int y, string cn)
    {
        Title = t;//set the Title property
        Author = a;//set the Author property
        Publisher = p;//set the Publisher property
        CopyrightYear = y;//set the Copyright property
        CallNumber = cn;//set the Callnumber property

    }
    //these are the instance variables that need to be a private and properties will be created for them
    private int copyrightYear;
    private bool isCheckedOut=false;//books are by default considered false or returned until checked out
    //auto-implemented properties for book object
    public string Title { get; set; }
    public string Author { get; set; }
    public string Publisher { get; set; }
    //copyright property that requires a certain number
    //Precondition: int >=0
    //Postcondition: will output the value given or 2019 if incorrect value
    public int CopyrightYear

    {
        // Precondition:  None
        // Postcondition: The copyright year has been returned
        get { return copyrightYear; }
        // Precondition: value>=0
        // Postcondition: The copyright year has been set to the specified value
        set
        {
            if (value >= 0)
                copyrightYear = value;
            else
                copyrightYear = 2019;
        }
    }
    public string CallNumber { get; set; }
    //method to change instance variable of checkedout to true
    //Precondition: None
    //Postcondition: the objects Checked Out status will be returned as true
    public void CheckOut()
    {
        isCheckedOut = true;
    }
    //method to change instance variable of checkedout to false
    //Precondition: None
    //Postcondition: the objects Checked Out status will be returned as false
    public void ReturnToShelf()
    {
        isCheckedOut = false;
    }
    //Precondition: None
    //Postcondition: the object's "Checked Out" status' actual Bool value is returned to the object
    public bool IsCheckedOut()
    {
            return isCheckedOut;
    }
    // Precondition:  None
    // Postcondition: A string is returned presenting the book in a 6-line format
    public override string ToString()
    {
        string result;//used to accumulate the string of data pieces over the course of 6 different lines and returning the variable to the console
        string status;//used with an ifelse in order to assign the appropriate status for the whether the book is checked out or returned
        result = $"Title: {Title}\n";
        result += $"Author: {Author}\n";
        result += $"Publisher: {Publisher}\n";
        result += $"Copyright: {CopyrightYear}\n";
        result += $"Callback Number: {CallNumber}\n";
        if (isCheckedOut == true)//displays the current status of the book's location based on the bool value
        {
            status = "Checked-out";
            result += $"Status: {status}\n";
        }
        else
        {
            status = "Returned";
            result += $"Status: {status}\n";
        }
        return result;
    }
}
