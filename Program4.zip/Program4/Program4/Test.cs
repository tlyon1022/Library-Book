﻿/*CIS 199-02
 * Program 4
 * December 3rd, 2019
 * K9195
 * A test program to display several objects created with the use of another class that 
 * dictates the properties, the constructor, and the string output format
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace LibraryTest
{
    class Test
    {
        // Precondition:  None
        // Postcondition: Several LibraryBook objects created and output
        static void Main(string[] args)
        {
            LibraryBook book1 = new LibraryBook("To Kill a Mocking Bird", "Haper Lee", "J. B. Lippincott & Co.", 1960, "AF245"); //All parts are filled out and will be presented as seen on seperate lines
            LibraryBook book2 = new LibraryBook("The Old Man and the Sea", "Ernest Hemingway", "Charles Scribner's Sons", 1952, "AF246");//All parts are filled out and will be presented as seen on seperate lines
            LibraryBook book3 = new LibraryBook("In the Shadow of the Sword", "Tom Holland", "Brown Little", 2012, "NF321");//All parts are filled out and will be presented as seen on seperate lines
            LibraryBook book4 = new LibraryBook("Yemen Chronicle: An Anthroplogy of War and Meditation", "Steven C. Carton", "Hill and Wang", 1979, "NF322");//All parts are filled out and will be presented as seen on seperate lines
            LibraryBook book5 = new LibraryBook("Nineteen Eighty-Four", "George Orwell", "Secker & Warburg", 1949, "AF247");//All parts are filled out and will be presented as seen on seperate lines
            LibraryBook[] books = { book1, book2, book3, book4, book5 };
            DisplayBooks(books);//method invoked to show array of library books
            book1.CheckOut();//Changes isCheckedOut bool to false
            book2.CheckOut();//Changes isCheckedOut bool to false
            book3.CallNumber = "NF678";//changes Callnumber for book3
            book1.CallNumber = "AF333";//changes Callnumber for book1
            book2.CallNumber = "AF666";//changes Callnumber for book2
            book4.Publisher = "Ya boi helped publish this";//changes publisher for book4
            book5.Publisher = "I, the internet hacker, published this one";//changes publisher for book5
            DisplayBooks(books);//method invoked to show array of library books
            book1.ReturnToShelf();//Changes isCheckedOut bool to true
            book2.ReturnToShelf();//Changes isCheckedOut bool to true
            DisplayBooks(books);//method invoked to show array of library books

        }
        //Precondition: must be given the defined array holding the references of the book objects created
        //Postcondition: will display each of the objects' data line by line
        static void DisplayBooks(LibraryBook[] books)
        {
            for(int x = 0;x<books.Length;++x)
            {
                WriteLine($"{books[x]}");
            }
        }
    }
}
